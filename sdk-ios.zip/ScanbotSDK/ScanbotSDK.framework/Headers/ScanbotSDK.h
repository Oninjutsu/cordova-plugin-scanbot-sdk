//
//  ScanbotSDK.h
//  ScanbotSDK
//
//  Created by Sebastian Husche on 26.06.15.
//  Copyright (c) 2015 doo GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ScanbotSDK.
FOUNDATION_EXPORT double ScanbotSDKVersionNumber;

//! Project version string for ScanbotSDK.
FOUNDATION_EXPORT const unsigned char ScanbotSDKVersionString[];

#import <ScanbotSDK/SBSDKScanbotSDK.h>
